# Acumen-2015
A website developed for Acumen 2015 , A Technical fest which held in Vasavi College of Engineering.  
Feel free to use it as a template for your college fests or any other event.
